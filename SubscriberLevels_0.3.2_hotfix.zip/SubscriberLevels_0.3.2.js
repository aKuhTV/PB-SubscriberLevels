/**
 * SubscriberLevels by aKuhTV
 *
 * Find out for how many months you have been subscribed (and which Level you are on)
 */

 (function() {

	var dbExists = $.inidb.FileExists('ResubMonths');

	if (dbExists){

		$.consoleLn('Resub Database found!');

	} else {

		$.consoleLn('Resub Database not found, creating new Database.');
		$.inidb.AddFile('ResubMonths');
		dbExists = $.inidb.FileExists('ResubMonths');

			if (dbExists){

				$.consoleLn('Resub Database created successfully!');

			}
	}


	var levelDbExists = $.inidb.FileExists('ResubLevelNames');

	if (levelDbExists){

		$.consoleLn('Resub Level Names Database found!');

	} else {

		$.consoleLn('Resub Level Names Database not found, creating new Database.');
		$.inidb.AddFile('ResubLevelNames');
		levelDbExists = $.inidb.FileExists('ResubLevelNames');

			if (levelDbExists){

				$.consoleLn('Resub Level Names Database created successfully!');

			}
	}


	var settingsDbExists = $.inidb.FileExists('ResubLevelSettings');

	if (settingsDbExists){

		$.consoleLn('SubscriberLevels Settings Database found!');

		// UPDATE 0.3.1 //

		if ($.inidb.exists('ResubLevelSettings', 'APIsync')) {
		
			//return;

		} else {
		
			$.consoleLn('SubscriberLevels Settings Database outdated. Updating...');
			$.inidb.set('ResubLevelSettings', 'APIsync', 'true');

		}

	} else {

		$.consoleLn('SubscriberLevels Settings Database not found, creating new Database.');
		$.inidb.AddFile('ResubLevelSettings');
		$.inidb.set('ResubLevelSettings', 'subEmote', 'bleedPurple');
		$.inidb.set('ResubLevelSettings', 'sadEmote', 'BibleThump');
		$.inidb.set('ResubLevelSettings', 'subName', 'Sub');
		settingsDbExists = $.inidb.FileExists('ResubLevelSettings');

			if (settingsDbExists){

				$.consoleLn('SubscriberLevels Settings Database created successfully!');

			}
	}


	/*
     * @event twitchSubscriber
     */
    $.bind('twitchSubscriber', function(event) {

        var subscriber = event.getSubscriber();
//			months = event.getMonths();

        if($.inidb.exists('ResubMonths', subscriber)){
			
			$.inidb.incr('ResubMonths', subscriber, 1);

		} else {
			
			$.inidb.set('ResubMonths', subscriber, 1);
			$.say('subtest');

		}
    });

    /*
     * @event twitchPrimeSubscriber
     */
    $.bind('twitchPrimeSubscriber', function(event) {

        var subscriber = event.getSubscriber();

        if($.inidb.exists('ResubMonths', subscriber)){
			
			$.inidb.incr('ResubMonths', subscriber, 1);

		} else {
			
			$.inidb.set('ResubMonths', subscriber, 1);

		}
    });

    /*
     * @event twitchReSubscriber
     */
    $.bind('twitchReSubscriber', function(event) {

        var resubscriber = event.getReSubscriber();
			months = event.getMonths();
			
		
		if($.inidb.exists('ResubMonths', resubscriber) && $.inidb.get('ResubLevelSettings', 'APIsync') == 'true') {
			
			$.inidb.set('ResubMonths', resubscriber, months);

		} else if ($.inidb.exists('ResubMonths', resubscriber) && $.inidb.get('ResubLevelSettings', 'APIsync') == 'false') {

			$.inidb.incr('ResubMonths', resubscriber, 1);

		} else {
			
			$.inidb.set('ResubMonths', resubscriber, months);

		}
    });

    /*
     * @event twitchSubscriptionGift
     */
    $.bind('twitchSubscriptionGift', function(event) {

        var recipient = event.getRecipient();

		if($.inidb.exists('ResubMonths', recipient)){
			
			$.inidb.incr('ResubMonths', recipient, 1);

		} else {
			
			$.inidb.set('ResubMonths', recipient, 1);

		}
    });


    /*
     * @event twitchAnonymousSubscriptionGift
     */
    $.bind('twitchAnonymousSubscriptionGift', function(event) {

        var recipient = event.getRecipient();

        if($.inidb.exists('ResubMonths', recipient)){
			
			$.inidb.incr('ResubMonths', recipient, 1);

		} else {
			
			$.inidb.set('ResubMonths', recipient, 1);

		}
    });


    /**
     * @event command
     */
	$.bind('command', function(event) {
		var sender = event.getSender(),
			command = event.getCommand(),
			args = event.getArgs();
			arguments = event.getArguments();
			resubMonths = $.inidb.get('ResubMonths', sender);
			isSub = $.inidb.get('subscribed', sender);
			levelName = $.inidb.get('ResubLevelNames', resubMonths);

			subEmote = $.inidb.get('ResubLevelSettings', 'subEmote');
			sadEmote = $.inidb.get('ResubLevelSettings', 'sadEmote');
			subName = $.inidb.get('ResubLevelSettings', 'subName');

		if(command.equalsIgnoreCase('level')) {

			if (args[0] != undefined) {

				argIsSub = $.inidb.get('subscribed', args[0].toLowerCase());
				argResubMonths = $.inidb.get('ResubMonths', args[0].toLowerCase());
				argLevelName = $.inidb.get('ResubLevelNames', argResubMonths);

				//$.say($.lang.get('subscriberlevels.ownlevelonly', sender));

				if (argIsSub == 'true' && argResubMonths != null) {

					if (argLevelName != null) {

						if (argResubMonths == 1) {
				
							$.say($.lang.get('subscriberlevels.arglevelone', args[0], subName, argLevelName, subEmote));

						} else {

							$.say($.lang.get('subscriberlevels.arglevel', args[0], argResubMonths, subName, argLevelName, subEmote));

						}

					} else {

						if (argResubMonths == 1) {
					
							$.say($.lang.get('subscriberlevels.argsubone', args[0], subName, subEmote));

						} else {
						
							$.say($.lang.get('subscriberlevels.argsub', args[0], argResubMonths, subName, subEmote));

						}

					}

				} else if (argIsSub == 'true' && argResubMonths == null) {
				
					$.say($.lang.get('subscriberlevels.nodata', sender));

				} else {
				
					$.say($.lang.get('subscriberlevels.nosubarg', args[0], sadEmote, subName));

				}

			} else {
			
				if (isSub == 'true' && resubMonths != null) {

					if (levelName != null) {

						if (resubMonths == 1) {
				
							$.say($.lang.get('subscriberlevels.levelone', sender, subName, levelName, subEmote));

						} else {
						
							$.say($.lang.get('subscriberlevels.level', sender, resubMonths, subName, levelName, subEmote));

						}

					} else {

						if (resubMonths == 1) {
					
							$.say($.lang.get('subscriberlevels.subone', sender, subName, subEmote));

						} else {
						
							$.say($.lang.get('subscriberlevels.sub', sender, resubMonths, subName, subEmote));

						}

					}

				} else if (isSub == 'true' && resubMonths == null) {
				
					$.say($.lang.get('subscriberlevels.datanextmonth', sender));

				} else {
				
					$.say($.lang.get('subscriberlevels.nosub', sender, sadEmote, subName));

				}
			}
		}


		if (command.equalsIgnoreCase('setlevelname')) {
		
			if (args[1] != undefined) {
			
				$.inidb.set('ResubLevelNames', args[0], args[1]);
				$.say($.lang.get('subscriberlevels.levelnameset', args[0], args[1]));

			} else {
			
				$.say($.lang.get('subscriberlevels.setlevelnameusage'));

			}

		}


		if(command.equalsIgnoreCase('levelname')) {
		
			if (args[0] != undefined && $.inidb.get('ResubLevelNames', args[0]) != null) {
			
				var levelName = $.inidb.get('ResubLevelNames', args[0]);

				$.say($.lang.get('subscriberlevels.levelname', args[0], levelName));

			} else if (args[0] != undefined && $.inidb.get('ResubLevelNames', args[0]) == null) {

				$.say($.lang.get('subscriberlevels.nolevelname', args[0]));

			} else {
			
				$.say($.lang.get('subscriberlevels.levelnameusage'));

			}

		}


		if (command.equalsIgnoreCase('setsubemote')) {
		
			if (args[0] != undefined) {
			
				$.inidb.set('ResubLevelSettings', 'subEmote', args[0]);
				$.say($.lang.get('subscriberlevels.subemoteset', args[0]));

			} else {

				$.say($.lang.get('subscriberlevels.setemoteusage'));

			}

		}


		if (command.equalsIgnoreCase('setsademote')) {
		
			if (args[0] != undefined) {
			
				$.inidb.set('ResubLevelSettings', 'sadEmote', args[0]);
				$.say($.lang.get('subscriberlevels.sademoteset', args[0]));

			} else {
			
				$.say($.lang.get('subscriberlevels.setemoteusage'));

			}

		}


		if (command.equalsIgnoreCase('setsubname')) {
		
			if (args[0] != undefined) {
			
				$.inidb.set('ResubLevelSettings', 'subName', args[0]);
				$.say($.lang.get('subscriberlevels.subnameset', args[0]));


			} else {
			
				$.say($.lang.get('subscriberlevels.setsubnameusage'));

			}

		}


		if (command.equalsIgnoreCase('setlevel')) {
		
			if (args[1] != undefined) {
			
				$.inidb.set('ResubMonths', args[0], args[1]);
				$.say($.lang.get('subscriberlevels.levelset', args[0], args[1]));

			} else {
			
				$.say($.lang.get('subscriberlevels.setlevelusage'));

			}

		}


		if (command.equalsIgnoreCase('subnamechange')) {
		
			if (args[1] != undefined) {
			
				$.inidb.set('ResubMonths', args[1].toLowerCase(), $.inidb.get('ResubMonths', args[0].toLowerCase));
				$.inidb.del('ResubMonths', args[0].toLowerCase);
				$.say($.lang.get('subscriberlevels.subnamechanged', args[0], args[1]));

			} else {
			
				$.say($.lang.get('subscriberlevels.subnamechangeusage'));

			}

		}


		if (command.equalsIgnoreCase('apisync')) {

			if (args[0] != undefined) {
		
				if (arguments.equalsIgnoreCase('on')) {
			
					$.inidb.set('ResubLevelSettings', 'APIsync', 'true');
					$.say($.lang.get('subscriberlevels.apisyncon'));

				} else if (arguments.equalsIgnoreCase('off')) {
				
					$.inidb.set('ResubLevelSettings', 'APIsync', 'false');
					$.say($.lang.get('subscriberlevels.apisyncoff'));

				} else if (arguments.equalsIgnoreCase('status')) {

					var apisyncstatus = $.inidb.get('ResubLevelSettings', 'APIsync');

					if (apisyncstatus == 'true') {

						$.say($.lang.get('subscriberlevels.apisyncstatuson'))

					} else if (apisyncstatus == 'false') {

						$.say($.lang.get('subscriberlevels.apisyncstatusoff'))

					}

				} else {
				
					$.say($.lang.get('subscriberlevels.apisyncusage'));

				}

			} else {
			
				$.say($.lang.get('subscriberlevels.apisyncusage'));

			}
		}

	});


	 /**
     * @event initReady
     */
    $.bind('initReady', function() {
        if ($.bot.isModuleEnabled('./custom/SubscriberLevels_0.3.2.js')) {

			$.consoleLn('** SubscriberLevels by aKuhTV, v. 0.3.2 (C)2019 **');

            $.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'level', 7);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'setlevelname', 1);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'levelname', 1);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'setsubemote', 1);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'setsademote', 1);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'setsubname', 1);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'subnamechange', 2);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'setlevel', 1);
			$.registerChatCommand('./custom/SubscriberLevels_0.3.2.js', 'apisync', 1);

        }
    });

 })();