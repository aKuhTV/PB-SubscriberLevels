// SubscriberLevels English Lang File for v.0.3.1 and lower

$.lang.register('subscriberlevels.nosubarg', '$1 is not a $3 at the moment. $2');
$.lang.register('subscriberlevels.ownlevelonly', '$1, you can only check your own level.');
$.lang.register('subscriberlevels.arglevelone', '$1 is a $2 in the first month and has reached Level $3 $4');
$.lang.register('subscriberlevels.arglevel', '$1 has been a $3 for $2 months and has reached Level $4 $5');
$.lang.register('subscriberlevels.argsubone', '$1 is a $2 in the first month $3');
$.lang.register('subscriberlevels.argsub', '$1 has been a $3 for $2 months $4');
$.lang.register('subscriberlevels.levelone', '$1 is a $2 in the first month and has reached Level $3 $4');
$.lang.register('subscriberlevels.level', '$1 has been a $3 for $2 months and has reached Level $4 $5');
$.lang.register('subscriberlevels.subone', '$1 is a $2 in the first month $3');
$.lang.register('subscriberlevels.sub', '$1 has been a $3 for $2 months $4');
$.lang.register('subscriberlevels.datanextmonth', 'You can check you level after your next resub, $1');
$.lang.register('subscriberlevels.nosub', 'You are not a $3 at the moment, $1 $2');

$.lang.register('subscriberlevels.levelnameset', 'The name of level $1 was changed to $2.');
$.lang.register('subscriberlevels.setlevelnameusage', 'Set a name for a specific level. Example: !setlevelname 1 Newbee');
$.lang.register('subscriberlevels.levelname', 'Name of level $1: $2');
$.lang.register('subscriberlevels.nolevelname', 'Level $1 has no name yet. Use !setlevelname to name it.');
$.lang.register('subscriberlevels.levelnameusage', 'Specify the level, you want to rename. Example: !levelname 1');

$.lang.register('subscriberlevels.subemoteset', 'The Sub-Emote in Level-Checks is now $1');
$.lang.register('subscriberlevels.sademoteset', 'The Non-Sub-Emote in Level-Checks is now $1.');
$.lang.register('subscriberlevels.setemoteusage', 'Specify the Emote you want to use.');

$.lang.register('subscriberlevels.subnameset', 'Your Sub-Role is now named $1');
$.lang.register('subscriberlevels.setsubnameusage', 'Set a custom name for your Sub-Role. (Default is Sub) Example: !setsubname SuperCow');

$.lang.register('subscriberlevels.levelset', '�1 is now at Level $2.');
$.lang.register('subscriberlevels.setlevelusage', 'Specify a username and a level-number. Example: !setlevel aKuhTV 3 - Be careful, this command overwrites existing userdata in the bot-database, which can lead to different values than Twitchs Resub count!');

$.lang.register('subscriberlevels.subnamechanged', '$1 s levels have been transferred to $2.');
$.lang.register('subscriberlevels.subnamechangeusage', 'Specify the old and the new username to transfer the levels. Example: !subnamechange OldName NewName');

$.lang.register('subscriberlevels.nodata', 'Seems like I dont have any data about that, $1');
$.lang.register('subscriberlevels.apisyncon', 'Syncronisation of sub-months with Twitchs API is now active. Note, that a users data is only synced on their RESUB event.');
$.lang.register('subscriberlevels.apisyncoff', ' ItsBoshyTime Syncronisation of sub-months with Twitchs API is now disabled. (Not recommended)');
$.lang.register('subscriberlevels.apisyncusage', 'Toggle the syncronisation of sub-months with Twitchs API using !apisync [on|off] or check the status with !apisync status - Default and recommended is ON.');
$.lang.register('subscriberlevels.apisyncstatuson', 'Syncronisation of sub-months with Twitchs API is active.');
$.lang.register('subscriberlevels.apisyncstatusoff', 'ItsBoshyTime Syncronisation of sub-months with Twitchs API is DISABLED. Toggle the syncronisation with Twitchs API using !apisync [on|off] - Default and recommended is ON.');