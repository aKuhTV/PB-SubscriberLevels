// SubscriberLevels German Lang File for v.0.3 and up

$.lang.register('subscriberlevels.nosubarg', '$1 ist momentan kein Sub. $2');
$.lang.register('subscriberlevels.ownlevelonly', '$1, du kannst nur deinen eigenen Level abfragen.');
$.lang.register('subscriberlevels.arglevelone', '$1 ist Sub im ersten Monat und somit $2 des Levels $3 $4');
$.lang.register('subscriberlevels.arglevel', '$1 ist seit $2 Monaten Sub und somit $3 des Levels $4 $5');
$.lang.register('subscriberlevels.argsubone', '$1 ist $2 im ersten Monat $3');
$.lang.register('subscriberlevels.argsub', '$1 ist seit $2 Monaten $3 $4');
$.lang.register('subscriberlevels.levelone', '$1 ist Sub im ersten Monat und somit $2 des Levels $3 $4');
$.lang.register('subscriberlevels.level', '$1 ist seit $2 Monaten Sub und somit $3 des Levels $4 $5');
$.lang.register('subscriberlevels.subone', '$1 ist $2 im ersten Monat $3');
$.lang.register('subscriberlevels.sub', '$1 ist seit $2 Monaten $3 $4');
$.lang.register('subscriberlevels.datanextmonth', 'Du kannst deinen Level ab deinem kommenden Resub abrufen, $1');
$.lang.register('subscriberlevels.nosub', 'Du bist momentan kein Sub, $1 $2');

$.lang.register('subscriberlevels.levelnameset', 'Der Name von Level $1 ist jetzt $2.');
$.lang.register('subscriberlevels.setlevelnameusage', 'Gib die Resub-Zahl und einen Level-Namen an. zB: !setlevelname 1 Neuling');
$.lang.register('subscriberlevels.levelname', 'Aktueller Name von Level $1: $2');
$.lang.register('subscriberlevels.nolevelname', 'Level $1 hat momentan noch keinen Namen. Lege mit !setlevelname einen fest.');
$.lang.register('subscriberlevels.levelnameusage', 'Gib die Level-Zahl an, um den Namen des jeweiligen Levels abzufragen. zB: !levelname 1');

$.lang.register('subscriberlevels.subemoteset', 'Das Sub-Emote in Level-Abfragen ist jetzt $1');
$.lang.register('subscriberlevels.sademoteset', 'Das Non-Sub-Emote in Level-Abfragen ist jetzt $1.');
$.lang.register('subscriberlevels.setemoteusage', 'Gib ein Emote an.');

$.lang.register('subscriberlevels.subnameset', 'Die Sub-Rolle heisst jetzt $1');
$.lang.register('subscriberlevels.setsubnameusage', 'Gib der Sub-Rolle einen Namen.');

$.lang.register('subscriberlevels.levelset', '�1 ist jetzt auf Resub-Level $2.');
$.lang.register('subscriberlevels.setlevelusage', 'Gib einen Nutzernamen und ein Level an. zB: !setlevel aKuhTV 3 - Vorsicht, hiermit bearbeitest du die Resub-Monate in der Bot-Datenbank, wodurch die Monatszahl von der tatsaechlichen Twitch-Resub-Zahl abweichen kann!');

$.lang.register('subscriberlevels.subnamechanged', 'Die Level von $1 wurden auf $2 transferiert.');
$.lang.register('subscriberlevels.subnamechangeusage', 'Gib den alten und den neuen Nutzernamen an, um die Level zu transferieren. zB: !subnamechange AlterName NeuerName');

$.lang.register('subscriberlevels.nodata', 'Dazu liegen mir keine Daten vor, $1');